---
description: "YouTube 心智圖企劃的 5 階段互動工作流程。V3 版本：雙欄佈局（左欄個人經驗 + 右欄主論述推導鏈）、JSON 輸出至 n8n Webhook 自動部署 Miro。當用戶開始新的影片企劃時觸發。"
---

# 心智圖企劃工作流程（V3 — 雙欄佈局）

## 核心原則

1. **一次只處理一個 section** — 不要一次生成所有內容
2. **每個 section 都要 Ray 確認** — 確認後才往下一個
3. **雙欄佈局** — 左欄（`column: "left"`）放個人經驗，右欄（默認）放主論述推導鏈
4. **先左後右** — 先完成左欄（免責聲明 → 我的經驗），再處理右欄
5. **鏈式連接** — 同一欄內的 section 之間串連（s1→s2），不是全部從 root 出發

---

## 階段一：主題發想與類型判斷

**觸發**：用戶提供影片主題或使用 `/new-video` 指令

1. 分析主題關鍵字，判斷最適合的影片類型（參考 content-templates 的 9 種模板）
2. 提供 3 個標題建議（繁體中文，帶括號副標）
3. 等 Ray 選擇或修改標題

**輸出**：確認的影片標題 + 影片類型

---

## 階段二：大綱骨架生成

根據確認的標題和類型，生成雙欄大綱骨架：

### 左欄（`column: "left"`）
- **免責聲明**（`white_container`）：個人經驗非絕對真理
- **我的經驗**（`section`）：相關個人背景、時間軸、成就

### 右欄（默認，不需 column 標記）
- **闡述問題**（`section`）：定義今天要討論的問題
- **說明原因**（`section`）：為什麼會這樣
- **給予理由**（`section`）：❶❷❸ 分組深入見解（`white_container` 子節點）
- **我的解法**（`section`）：實際做法 + 條件式結論
- **收尾金句**（`section`）：哲學式紅色大字
- **CTA**（`section`）：社群導流 + 影片推薦

**注意**：骨架可以根據影片類型調整，不必完全遵循上述結構。參考 content-templates 的對應模板。

**輸出**：雙欄大綱骨架（section 列表），等 Ray 確認

---

## 階段三：節點內容填充

確認骨架後，逐一填充每個 section 的子節點內容。

### 處理順序
1. **先左欄**：免責聲明 → 我的經驗
2. **再右欄**：按推導鏈順序逐一處理

### 每個 section 的處理流程
1. 提供該 section 的 2-4 個子節點建議
2. 標記每個節點的 `style`：
   - `normal`：一般論點
   - `red_emphasis`：核心觀點/警告
   - `blue_underline`：反面教材
   - `screenshot`：截圖預留位置
   - `quote`：引用語句
3. 等 Ray 確認、修改或補充
4. 確認後進入下一個 section

### 語氣風格
- 所有節點文字套用 tone-and-voice skill
- 左欄偏「分享/自嘲」語氣
- 右欄偏「推導/教育」語氣
- 節點文字簡短有力，帶口語感

**輸出**：每個 section 的完整子節點（逐一確認）

---

## 階段四：視覺排版建議

所有節點內容確認後，提供視覺排版建議：

1. **截圖清單**：列出所有 `screenshot` 節點，建議需要準備的截圖
2. **紅字檢查**：確認 `red_emphasis` 節點不超過 2-3 行，夠精煉
3. **藍字檢查**：確認 `blue_underline` 只用於反面教材
4. **特殊元素建議**：根據 miro-layout-patterns 的 37 種模式，建議適合的視覺元素

**輸出**：視覺排版建議清單 + 截圖準備清單

---

## 階段五：JSON 輸出與 Miro 部署

最終確認後，生成 JSON 並部署到 Miro：

1. 組裝完整 JSON payload（樹狀結構）
2. 確認所有欄位：
   - 每個節點有 `id`、`text`、`style`、`children`
   - 左欄 section 有 `"column": "left"`
   - `board_id` 設為 `uXjVLCeP6Ro=`
3. 展示完整 JSON 給 Ray 最終確認
4. POST 到 `https://david86726.app.n8n.cloud/webhook/miro-mindmap`
5. 等待 n8n 處理完成
6. 提供 Miro 看板連結讓 Ray 檢查

### JSON 格式範例

```json
{
  "board_id": "uXjVLCeP6Ro=",
  "nodes": {
    "id": "root",
    "text": "影片標題",
    "style": "root",
    "children": [
      {
        "id": "s1",
        "text": "免責聲明",
        "style": "white_container",
        "column": "left",
        "children": [
          { "id": "s1-1", "text": "...", "style": "normal", "children": [] }
        ]
      },
      {
        "id": "s3",
        "text": "右欄 section",
        "style": "section",
        "children": [ ... ]
      }
    ]
  }
}
```

**輸出**：Miro 看板上的完整心智圖 + 截圖準備清單
