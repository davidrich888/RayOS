---
description: "開始一個新的 YouTube 影片心智圖企劃"
---

# 新影片企劃

開始一個新的影片企劃心智圖。

用戶提供的資訊：$ARGUMENTS

## 執行流程

1. 根據主題自動判斷影片類型（參考 content-templates skill 的 9 種模板）
2. 提供 3 個標題建議（帶括號副標，繁體中文）
3. 等用戶確認標題後，生成**雙欄結構**的心智圖大綱骨架：
   - **左欄**（`column: "left"`）：免責聲明 → 我的經驗（先講完個人背景）
   - **右欄**（默認）：闡述問題 → 說明原因 → 給予理由（❶❷❸分組）→ 我的解法 → 收尾金句 → CTA
4. 逐一跟用戶討論每個 section 的內容（先左欄，再右欄）
5. 所有節點文字使用 tone-and-voice skill 的語氣風格
6. 標記每個節點的 `style`（normal / red_emphasis / blue_underline / screenshot / quote）
7. 最終輸出 JSON 格式，發送到 n8n Webhook 自動部署到 Miro

## 雙欄佈局規則

- 左欄 section 需標記 `"column": "left"`，右欄不需要（默認右欄）
- 同一欄內的 section 之間用**鏈式連接**（s1→s2，不是全部從 root 出發）
- ❶❷❸ 類深入見解分組為同一個 section 的子節點（用 `white_container` 樣式）
- 可用的節點樣式：`root`、`section`、`white_container`、`normal`、`red_emphasis`、`blue_underline`、`screenshot`、`quote`

## 注意

- 如果用戶只給了模糊主題（例如「講 Prop Firm」），先追問想傳達的核心訊息
- 如果用戶已有明確標題，直接跳過標題發想
- 所有輸出使用繁體中文
- 語氣參照 tone-and-voice skill：對話式、自嘲式誠實、具體數字佐證
- 每次只處理一個 section，不要一次全部完成
