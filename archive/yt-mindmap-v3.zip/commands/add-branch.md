---
description: "為心智圖增加一個主要分支"
---

# 增加分支

為目前的心智圖企劃增加一個新的主要分支（section）。

用戶提供的資訊：$ARGUMENTS

## 執行流程

1. 確認新分支要加在哪一欄：
   - **左欄**（`column: "left"`）：個人經驗相關內容
   - **右欄**（默認）：主論述推導鏈上的新段落
2. 確認新分支在該欄中的位置（插在哪個 section 之後）
3. 根據用戶描述，生成該分支的完整節點結構
4. 套用 tone-and-voice 語氣風格
5. 標記每個節點的 `style`（normal / red_emphasis / blue_underline / screenshot / quote）
6. 如果是❶❷❸類分組，用 `white_container` 樣式作為子分組標題
7. 確認與前後 section 的推導邏輯是否通順

## 注意

- 新增左欄分支需標記 `"column": "left"`
- 新增右欄分支不需要 column 標記（默認右欄）
- 鏈式連接會自動處理：新 section 會連接到同欄的前一個 section
