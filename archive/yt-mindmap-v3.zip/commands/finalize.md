---
description: "完成心智圖並輸出 JSON 到 Miro"
---

# 完成企劃

完成目前的心智圖企劃，輸出 JSON 並發送到 n8n Webhook 自動部署到 Miro。

## 執行流程

1. 檢查所有分支的完整性（左欄和右欄都已確認）
2. 確認每個節點的 `style` 標記正確：
   - `root`：影片標題（置頂中央）
   - `section`：各段落標題（28px 黑色粗體）
   - `white_container`：❶❷❸ 分組標題（24px 灰色粗體）
   - `normal`：一般論點（18px 黑色）
   - `red_emphasis`：核心觀點/警告（18px 紅色）
   - `blue_underline`：反面教材/行銷話術（18px 藍色）
   - `screenshot`：截圖預留位置（14px 灰色有底色）
   - `quote`：引用語句（18px 黃色底）
3. 確認左欄 section 都有 `"column": "left"` 標記
4. 生成完整 JSON payload（樹狀結構）
5. POST 到 n8n Webhook URL：`https://david86726.app.n8n.cloud/webhook/miro-mindmap`
6. n8n 自動在 Miro 上建立所有文字節點和連接線
7. 提供影片拍攝提示（需要準備的截圖清單）

## JSON 格式

```json
{
  "board_id": "uXjVLCeP6Ro=",
  "nodes": {
    "id": "root",
    "text": "影片標題",
    "style": "root",
    "children": [
      {
        "id": "s1",
        "text": "免責聲明",
        "style": "white_container",
        "column": "left",
        "children": [
          { "id": "s1-1", "text": "節點文字", "style": "normal", "children": [] }
        ]
      },
      {
        "id": "s2",
        "text": "我的經驗",
        "style": "section",
        "column": "left",
        "children": [ ... ]
      },
      {
        "id": "s3",
        "text": "右欄第一個 section",
        "style": "section",
        "children": [ ... ]
      }
    ]
  }
}
```

## 注意

- 只有左欄 section 需要 `"column": "left"`，右欄不需要（默認）
- 同一欄內 section 之間會自動建立鏈式連接（由 n8n 處理）
- `board_id` 固定為 `uXjVLCeP6Ro=`（Ray 的 Miro 看板）
- 發送前先給 Ray 看完整 JSON，確認後再發送
- 發送後提供 Miro 看板連結供 Ray 檢查
